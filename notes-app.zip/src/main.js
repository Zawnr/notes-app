import runApp from './script/app.js';

document.addEventListener('DOMContentLoaded', runApp);
